# WorkSphere - Diabetic Retinopathy Image Processing System
## Task 3: Develop Login & Registration Pages for all Dashboards
**Intern Author:** Chinmay K V (@Chinmaykv)  
**Track:** Full-Stack AI & Software Engineering  
**Submission Date:** September 2026  

### Architecture & Overview
This package delivers the complete authentication subsystem for the WorkSphere platform:
1. **Multi-Role Authentication**: Dedicated and unified login flows for Admin, Intern, and Client (Doctor/Clinician) roles.
2. **Form Validation**: Real-time email syntax verification, password strength requirements (min 8 chars, mixed case, special symbols), and match validation.
3. **Security Standards**: BCrypt password hashing, signed JWT Bearer token generation, and role-guarded routes.
4. **Responsive Frontend**: React 19 + TailwindCSS glassmorphism aesthetic with Lucide iconography.

### Included Source Components
- `src/components/Login.jsx` - Dynamic multi-role login interface
- `src/components/Register.jsx` - Account creation with role selection
- `src/context/AuthContext.jsx` - Global authentication provider and state hooks
- `src/controllers/AuthController.java` - Spring Boot REST controller for /api/auth/*
- `src/services/UserService.java` - User credential validation & JWT generation
- `src/models/User.java` - User domain model with role-based authorities
- `package.json` - Frontend configuration & dependency manifest
