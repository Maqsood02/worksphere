package com.freelancer.platform.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        String password = payload.get("password");
        String role = payload.getOrDefault("role", "INTERN");

        if (email == null || password == null) {
            return ResponseEntity.badRequest().body(Map.of("message", "Email and password are required."));
        }

        // Mock token generation for verified demonstration
        Map<String, Object> response = new HashMap<>();
        response.put("token", "ws_jwt_" + System.currentTimeMillis() + "_" + role.toLowerCase());
        response.put("user", Map.of(
            "email", email,
            "role", role,
            "name", email.split("@")[0]
        ));
        return ResponseEntity.ok(response);
    }
}
